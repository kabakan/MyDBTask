﻿Для запуска приложения требуется БД Postgres

1. Перед запускам приложеня требуется настройка конфигураций db.properties во вложений
2. Для записи данных в БД команда: java -cp MyDBTask-1.0.jar com.main.Application
3. Для вывода данных из БД команда: java -cp MyDBTask-1.0.jar com.main.Application -p