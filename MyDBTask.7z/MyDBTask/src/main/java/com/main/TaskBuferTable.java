package com.main;

import com.util.AdapterDB;
import com.util.Model;
import com.util.StateDB;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TimerTask;

public class TaskBuferTable extends TimerTask {

  private List<Timestamp> ltime = new ArrayList<Timestamp>();

  public void run() {
    try {
      Timestamp timestamp = Timestamp.valueOf(LocalDateTime.now());
      if (checkConnect()) {
        System.out.println("Set Table !");
        this.ltime.add(timestamp);
        Model model = AdapterDB.getModel();
        for(Timestamp times : ltime) {
           model.postLink(times);
        }
        this.ltime.clear();
      } else {
        System.out.println("Set Buffer List Timestamp! "+timestamp);
        this.ltime.add(timestamp);
      }
    } catch (Exception ex) {
      System.out.println("run() error: "+ex.getMessage());
    }
  }

  public static Boolean checkConnect() {
    try {
      Boolean state = false;
      if (StateDB.state == 1) {
      //  System.out.println("StateDB.state = "+StateDB.state);
        state = true;
      } else  {
        state = false;
      //  System.out.println("StateDB.state = "+StateDB.state);
      }
      return state;
    } catch (Exception ex) {
      return false;
    }
  }
}
