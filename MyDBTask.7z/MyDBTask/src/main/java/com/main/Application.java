package com.main;

import com.entity.LinkTmp;
import com.util.AdapterDB;
import com.util.Model;
import java.util.List;
import java.util.Timer;

public class Application {

  public static void main(String[] args) {
    try {
      String s1 ="0";
      System.out.println("Start Database Test!");
      for (String s: args) {
        if ("-p".equals(s)) {
          s1 = s;
        }
        System.out.println(s);
      }
      AdapterDB adb = new AdapterDB();
      Model model = AdapterDB.getModel();
      model.createTable();

      if ("-p".equals(s1)) {
        System.out.println("DB connection !");
        List<LinkTmp> ltmp = AdapterDB.getModel().getAllLink();
        ltmp.forEach(link -> {
          System.out.println("Id: "+link.getId()+" Timestamp: "+link.getSend_time());
        });
        System.out.println("Finish Database Test!");
        return;
      } else {
        checkDbConnet();
        setTable();
      }

    }
    catch (Exception ex) {
      System.out.println(ex.getMessage());
    }
  }

  public static void checkDbConnet() {
    Timer timer = new Timer();
    timer.schedule(new TaskDBConnect(), 0, 5000);
  }

  public  static void setTable() {
      Timer timer = new Timer();
      timer.schedule(new TaskBuferTable(), 0, 1000);
  }


}
