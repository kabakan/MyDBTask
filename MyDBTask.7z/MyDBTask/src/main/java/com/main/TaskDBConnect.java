package com.main;

import com.util.AdapterDB;
import com.util.Model;
import com.util.StateDB;
import java.util.TimerTask;


public class TaskDBConnect extends TimerTask {

  public void run() {
    try {
      Model model = AdapterDB.getModel();
      model.getLinkId();
      StateDB.state = 1;
      System.out.println("DB Connect Success!");
    } catch (Exception ex) {
      System.out.println("DB Connect Failed!");
      StateDB.state = 0;
      System.out.println("TaskDBConnect Error: "+ex.getMessage());
    }
  }
}
