package com.entity;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ConfigDB {
  private String dbip;
  private String dbport;
  private String dbname;
  private String dbuser;
  private String dbpass;
  private static ConfigDB instance;

  public static final String DB_PATH_CONFIG = "./db.properties";

  public ConfigDB(){
    try {
    File file = new File(DB_PATH_CONFIG);
    FileInputStream fileInput = new FileInputStream(file);
    Properties props = new Properties();
    props.load(fileInput);
    fileInput.close();
    this.setDbip(props.getProperty("db.ip-address"));
    this.setDbport(props.getProperty("db.port"));
    this.setDbname(props.getProperty("db.schema"));
    this.setDbuser(props.getProperty("db.user"));
    this.setDbpass(props.getProperty("db.pass"));
    } catch (Exception ex) {
      System.out.println("Error " + ex.getMessage());
    }
  }

  public String getDbip() {
    return dbip;
  }

  public void setDbip(String dbip) {
    this.dbip = dbip;
  }

  public String getDbport() {
    return dbport;
  }

  public void setDbport(String dbport) {
    this.dbport = dbport;
  }

  public String getDbname() {
    return dbname;
  }

  public void setDbname(String dbname) {
    this.dbname = dbname;
  }

  public String getDbuser() {
    return dbuser;
  }

  public void setDbuser(String dbuser) {
    this.dbuser = dbuser;
  }

  public String getDbpass() {
    return dbpass;
  }

  public void setDbpass(String dbpass) {
    this.dbpass = dbpass;
  }

  public static ConfigDB getInstance(){
    if(instance == null){
      instance = new ConfigDB();
    }
    return instance;
  }
}
