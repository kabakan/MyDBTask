package com.entity;

import lombok.Data;

@Data
public class LinkTmp {
  private long id;
  private java.sql.Timestamp send_time;
}
