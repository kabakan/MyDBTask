package com.util;

public class StateDB {
  public static int state =0;
}
