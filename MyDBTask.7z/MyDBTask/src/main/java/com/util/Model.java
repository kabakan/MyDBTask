package com.util;

import com.entity.LinkTmp;
import java.util.List;

public interface Model {
   void createTable();
   LinkTmp getLinkId();
   List getAllLink();
   void postLink(java.sql.Timestamp sendtime);
   void updateLink(Integer id, java.sql.Timestamp sendtime);
}
