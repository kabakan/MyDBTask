package com.util;

import com.entity.ConfigDB;
import com.quirks.PostgresQuirks;
import java.util.UUID;
import org.sql2o.Sql2o;
import org.sql2o.converters.UUIDConverter;


public class AdapterDB {
  private Sql2o sql2o;
  private static Model model;


  public AdapterDB() {
    ConfigDB configDB = ConfigDB.getInstance();

    this.sql2o = new Sql2o(
        "jdbc:postgresql://" + configDB.getDbip() + ":" + configDB.getDbport()+ "/" + configDB.getDbname(),
        configDB.getDbuser(), configDB.getDbpass(), new PostgresQuirks(){
      {
        // make sure we use default UUID converter.
        converters.put(UUID.class, new UUIDConverter());
      }
    });


    this.model = new Sql2oModel(sql2o);
  }

  public static Model getModel() {
    if(model == null) {
      new AdapterDB();
    }
   /*   System.out.println("model == null");
    } else {
      System.out.println("model !== null");
    }*/

    return model;
  }
}
