package com.util;

import com.entity.LinkTmp;
import java.sql.Timestamp;
import java.util.List;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

public class Sql2oModel implements Model {

  private Sql2o sql2o;
  public Sql2oModel(Sql2o sql2o) {
    this.sql2o = sql2o;
  }


  public LinkTmp getLinkId() {
    try(Connection conn = sql2o.open()){
      List<LinkTmp> temp = conn.createQuery("SELECT 1 as id from now()")
          .executeAndFetch(LinkTmp.class);
      return temp.get(0);
    }
  }

  public List getAllLink() {
    try(Connection conn = sql2o.open()){
      List<LinkTmp> ltmp = conn.createQuery("SELECT id, send_time FROM link_tmp")
          .executeAndFetch(LinkTmp.class);
      return ltmp;
    }
  }

  public void postLink(Timestamp sendtime) {
    try {
      Connection conn = sql2o.beginTransaction();
      conn.createQuery("insert into link_tmp(send_time) "
          + "VALUES (:send_time)")
          .addParameter("send_time", sendtime)
          .executeUpdate();
      conn.commit();
    } catch (Exception ex) {
     // System.out.println("CreateLink Error: "+ex.getMessage());
      System.out.println("");
    }
  }

  public void updateLink(Integer id, Timestamp sendtime) {
    try {
      Connection conn = sql2o.beginTransaction();
      conn.createQuery("update link_tmp SET send_time = :sendtime where id = :id")
          .addParameter("sendtime", sendtime)
          .executeUpdate();
      conn.commit();
    } catch (Exception ex) {
      System.out.println("updateLink Error: "+ex.getMessage());
    }
  }

  public void createTable() {
    try {
      Connection conn = sql2o.beginTransaction();
      conn.createQuery("CREATE TABLE IF NOT EXISTS link_tmp\n"
                              + "( ID          SERIAL,\n"
                              + "  SEND_TIME   TIMESTAMP);")
          .executeUpdate();
      conn.commit();
    } catch (Exception ex) {
      System.out.println("createTable Error: "+ex.getMessage());
    }
  }
}